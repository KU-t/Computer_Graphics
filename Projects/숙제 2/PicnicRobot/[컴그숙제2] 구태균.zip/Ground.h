#pragma once
class Ground{
public:
	float x, y, z;
	
	Ground();
	void Draw();
};

