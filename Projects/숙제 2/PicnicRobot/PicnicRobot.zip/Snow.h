#pragma once
#include "Ingame.h"

class Snow {
public:
	int i, j;
	float y;
	
	Snow();
	~Snow();
	void Draw(int weather);
};

